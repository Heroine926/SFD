#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <vector>
#include <time.h>
#include <iosfwd>
#include <utility>


#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>


#include "/data/home/larainelu/SFD/caffe/examples/cpp_classification/soSFD.h"

using namespace std;
using namespace cv;

#define LIB_SFD "/data/home/larainelu/SFD/caffe/examples/cpp_classification/sfd_FaceDetect.so"



extern "C"
{
	typedef int (*F_sfd_face_detection)(const void *p_cvmat, void *p_vec_vec_rect, int batchSize);
	typedef int (*F_sfd_face_detection_init)(const string& model_def, const string& trained_file, int gpu_id);
}


int main()//int argc, char**argv)
{
    /*	if (argc != 3)
	{
	    	printf("Usage: %s <input_img_file> <img_list> \n", argv[0]);
		return 0;
	}

	::google::InitGoogleLogging(argv[0]);*/
	string model_file  = "/data/home/larainelu/SFD/caffe/models/VGGNet/WIDER_FACE/SFD_trained/deploy.prototxt"; // = argv[1];
	string trained_file = "/data/home/larainelu/SFD/caffe/models/VGGNet/WIDER_FACE/SFD_trained/SFD.caffemodel";// = argv[2];
	string test_image_path = "/data/home/larainelu/DataSet/h265Img/";//  = argv[1];
	string image_list_file = "/data/home/larainelu/DataSet/h265Img/image_list.txt";//  = argv[2];
	//string output_path        = argv[4];
        
	int res = 0;
	int gpu_id = 2;

	void *handle = dlopen(LIB_SFD,RTLD_LAZY);
	if(!handle)
	{
		printf("%s\n",dlerror());
		exit(EXIT_FAILURE);
	}

	char *error;
	dlerror();

	F_sfd_face_detection sfd_face_detection = (F_sfd_face_detection)dlsym(handle,"sfd_face_detection");
	F_sfd_face_detection_init sfd_face_detection_init = (F_sfd_face_detection_init)dlsym(handle,"sfd_face_detection_init");
	if((error = dlerror()) != NULL)
	{
		printf("%s\n",error);
		exit(EXIT_FAILURE);
	}
	
	res = sfd_face_detection_init(model_file, trained_file,gpu_id);
	printf("=====================finish loading network!=============================\n\n\n");
	ifstream img_list;
	img_list.open(image_list_file.data());

	if (!img_list)
	{
		std::cerr << image_list_file << " open error." <<endl;;
		exit(1);
	}
	string img_name;
	clock_t start_time = clock();
	int counter = 0;


	
	/*====================demo code when batch size is 1===================================================
	while(getline(img_list, img_name))
    	{
	  	printf("\n\nthe %dth picture...\n",counter+1);
		string Img_path = test_image_path + img_name;
									
		cv::Mat img = cv::imread(Img_path,-1);
		//cout<<Img_path<<endl;
		if(img.empty())
		{
		    	cout<<"image is empty"<<endl;
			//return 1;
		}
		//CHECK(!img.empty()) << "Unable to decode image " << Img_path;
		//int width = img.cols;
		//int height = img.rows;
		
		std::vector<std::vector<cv::Rect> > vrects;
		
		//cout<<"before sfd_det\n";
		//cout<<&vrects<<endl;
		res = sfd_face_detection(&img, &vrects,1);
		
		//cout<<"after sfd_det  .  res = "<<res<<endl;
		
		//cout<<&vrects<<endl;
		if(res != 0)
		{
			if(res == -1) 
			    cout<<"ERROR: p_cvmat is nullpr\n";
			if(res == -3)
			    cout<<"ERROR: img is empty\n";
			if(res == -5)
			    cout<<"ERROR: p_vec_vec_tect is nullpr\n";
			if(res == -7)
			    cout<<"ERROR: no target in this image\n";
			continue;
		}

		cout<<Img_path<<endl;
		std::vector<cv::Rect> &rects = vrects[0];
		cout<<"boxes number:"<<rects.size()<<endl;
		for(int i = 0;i < rects.size();i++)
		{
			cout<< rects[i].x<<"    ";
			cout<< rects[i].y<<"    ";
			cout<< rects[i].width<<"    ";
			cout<< rects[i].height<<"    ";
			cout<< endl;
		}
		counter++;
	}
	//=====================================================================================================*/



	
	//====================demo code when batch size is not 1===================================================
	bool end = false;
	int batchSize = 2;
	while(!end)
    	{
	    	vector<cv::Mat> img_vec;
		vector<string> Img_path_vec;

		
		while( (img_vec.size() < batchSize) && (!end) )
		{
		    	if(!getline(img_list,img_name))
			{
				end = true;
				batchSize = img_vec.size();
				if(batchSize == 0)
					break;
			}

			
			string Img_path = test_image_path + img_name;						
			cv::Mat img = cv::imread(Img_path,-1);
			if(img.empty())
			{
				cout<<"ERROR: "<<Img_path<<" is empty"<<endl;
				continue;
			}
			Img_path_vec.push_back(Img_path);
			img_vec.push_back(img);
		}
		//cout << img_vec.size()<<endl;
		
		std::vector<std::vector<cv::Rect> > vrects;
		
		res = sfd_face_detection(&img_vec[0], &vrects, batchSize);

		
		//cout<<"res = "<<res<<endl;
		if(res != 0)
		{
			if(res == -1) 
			    cout<<"ERROR: p_cvmat is nullpr\n";
			if(res == -3)
			    cout<<"ERROR: img is empty\n";
			if(res == -5)
			    cout<<"ERROR: p_vec_vec_tect is nullpr\n";
			if(res == -7)
			    cout<<"ERROR: no target in this image\n";
			continue;
		}
		for(int i = 0;i < batchSize;i++)
		{
			cout<<Img_path_vec[i]<<endl;
			std::vector<cv::Rect> &rects = vrects[i];
			//cout<<"rect num:"<<rects.size()<<endl;
			for(int i = 0;i < rects.size();i++)
			{
				cout<< rects[i].x<<"    ";
				cout<< rects[i].y<<"    ";
				cout<< rects[i].width<<"    ";
				cout<< rects[i].height<<"    ";
				cout<< endl;
			}
		}
		counter = counter+batchSize;
	}
	//=====================================================================================================*/
	




	clock_t end_time = clock();
        double mean_time = double((end_time-start_time))/CLOCKS_PER_SEC/(counter)*1000;
	printf("====================== elasped %f ms per image =========================\n",mean_time);

	dlclose(handle);
        //exit(EXIT_SUCCESS);

	return 0;
}

